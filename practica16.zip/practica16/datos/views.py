from django.shortcuts import render

# Create your views here.
def datos_(request):
    return render(request,"datos_.html")
    pass